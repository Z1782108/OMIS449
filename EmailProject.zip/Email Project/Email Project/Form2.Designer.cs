﻿namespace Email_Project
{
    partial class RecordInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayPhoneLabel = new System.Windows.Forms.Label();
            this.displayEmailLabel = new System.Windows.Forms.Label();
            this.displayNameLabel = new System.Windows.Forms.Label();
            this.phoneLabel = new System.Windows.Forms.Label();
            this.emailLabel = new System.Windows.Forms.Label();
            this.nameFirstLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // displayPhoneLabel
            // 
            this.displayPhoneLabel.AutoSize = true;
            this.displayPhoneLabel.Location = new System.Drawing.Point(278, 64);
            this.displayPhoneLabel.Name = "displayPhoneLabel";
            this.displayPhoneLabel.Size = new System.Drawing.Size(35, 13);
            this.displayPhoneLabel.TabIndex = 11;
            this.displayPhoneLabel.Text = "label6";
            // 
            // displayEmailLabel
            // 
            this.displayEmailLabel.AutoSize = true;
            this.displayEmailLabel.Location = new System.Drawing.Point(165, 64);
            this.displayEmailLabel.Name = "displayEmailLabel";
            this.displayEmailLabel.Size = new System.Drawing.Size(35, 13);
            this.displayEmailLabel.TabIndex = 10;
            this.displayEmailLabel.Text = "label5";
            // 
            // displayNameLabel
            // 
            this.displayNameLabel.AutoSize = true;
            this.displayNameLabel.Location = new System.Drawing.Point(56, 64);
            this.displayNameLabel.Name = "displayNameLabel";
            this.displayNameLabel.Size = new System.Drawing.Size(35, 13);
            this.displayNameLabel.TabIndex = 9;
            this.displayNameLabel.Text = "label4";
            // 
            // phoneLabel
            // 
            this.phoneLabel.AutoSize = true;
            this.phoneLabel.Location = new System.Drawing.Point(259, 37);
            this.phoneLabel.Name = "phoneLabel";
            this.phoneLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneLabel.TabIndex = 8;
            this.phoneLabel.Text = "Phone Number";
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.Location = new System.Drawing.Point(156, 37);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(58, 13);
            this.emailLabel.TabIndex = 7;
            this.emailLabel.Text = "Last Name";
            // 
            // nameFirstLabel
            // 
            this.nameFirstLabel.AutoSize = true;
            this.nameFirstLabel.Location = new System.Drawing.Point(46, 37);
            this.nameFirstLabel.Name = "nameFirstLabel";
            this.nameFirstLabel.Size = new System.Drawing.Size(57, 13);
            this.nameFirstLabel.TabIndex = 6;
            this.nameFirstLabel.Text = "First Name";
            // 
            // RecordInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 110);
            this.Controls.Add(this.displayPhoneLabel);
            this.Controls.Add(this.displayEmailLabel);
            this.Controls.Add(this.displayNameLabel);
            this.Controls.Add(this.phoneLabel);
            this.Controls.Add(this.emailLabel);
            this.Controls.Add(this.nameFirstLabel);
            this.Name = "RecordInformation";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label displayPhoneLabel;
        public System.Windows.Forms.Label displayEmailLabel;
        public System.Windows.Forms.Label displayNameLabel;
        private System.Windows.Forms.Label phoneLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label nameFirstLabel;
    }
}